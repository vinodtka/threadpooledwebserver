package com.web.webserver.exceptions;

/**
 * Created by Mihail on 10/24/2015.
 */
public class BadRequestException extends Exception {
}
