package com.web.webserver.exceptions;

/**
 * Created by Mihail on 10/24/2015.
 */
public class ConnectionClosedException extends Exception {
}
